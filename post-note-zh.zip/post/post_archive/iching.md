+++
date = "2017-02-13T14:15:36+08:00"
title = "iching: Practising Divination of I Ching"
tags = ['news', 'Python']
highlight = true
math = false
summary = """
[iching](https://pypi.python.org/pypi/iching/), a Python package that employs the Achillea millefolium method to practise divination of I Ching (易经的蓍草卜卦方法).
"""
[header]
  caption = ""
  image = ""

+++


[iching](https://pypi.python.org/pypi/iching/), a Python package that employs the Achillea millefolium method to practise divination of I Ching (易经的蓍草卜卦方法).

<iframe src="http://nbviewer.ipython.org/github/chengjun/iching/blob/master/iching_intro.ipynb" scrolling="no" width="700" height="6500"></iframe>
