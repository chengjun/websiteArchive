+++
highlight = true
math = false
date = "2017-02-13T14:32:07+08:00"
title = "Visualizing Global Terrorism using googleVis"
summary = """Using the Data from Global Terrorism Database (GTD) and googleVis-0.5.8, I visualize the global terrorism attacks over time. The remarkable negative relationship between kills and political stability can clearly observed.
"""
tags = ['news']
[header]
  image = "headers/forklift.svg"
  caption = ""

+++


Using the Data from Global Terrorism Database (GTD) and googleVis-0.5.8, I visualize the global terrorism attacks over time. The remarkable negative relationship between kills and political stability can clearly observed.

![](/img/headers/terrorism.png)

[Read More >>](http://chengjun.github.io/datajournalism/vis/terrorism/)
