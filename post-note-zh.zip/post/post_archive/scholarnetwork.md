+++
math = false
date = "2017-02-13T14:15:51+08:00"
title = "scholarnetwork: Crawl and Visualize the Coauthor Network"
tags = ['news', 'Python']
highlight = true

[header]
  caption = ""
  image = ""

+++

[scholarNetwork](https://pypi.python.org/pypi/scholarNetwork/), a Python package to crawl and visualize the coauthor network of Google Scholars.
