+++
date = "2017-02-13T14:16:05+08:00"
title = "networkdiffusion: Simulating and Visualizing Network Diffusion Using R"
tags = ['news', 'R']
highlight = true
math = false

[header]
  image = ""
  caption = ""

+++

[networkdiffusion](https://github.com/chengjun/networkdiffusion), an R package which can help simulate and visualize the network diffusion. [Slides](http://chengjunwang.com/network-diffusion/#/).

## Related Activity

Wang, C.J. (2017) [networkdiffusion](https://github.com/chengjun/networkdiffusion): Simulating and Visualizing Network Diffusion Using R. The 10th China R Conference. Beijing, May 20-21.
