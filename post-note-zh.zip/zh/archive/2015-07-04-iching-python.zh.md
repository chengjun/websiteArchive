---
title: "iching：一个用来算卦的python包"
date: 2015-07-04
---
<!--more-->

<iframe src="http://nbviewer.ipython.org/github/chengjun/iching/blob/master/iching_intro.ipynb" scrolling="no" width="700" height="6500"></iframe>
