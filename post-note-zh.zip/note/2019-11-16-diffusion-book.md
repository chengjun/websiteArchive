+++
date = "2019-11-11T12:00:00"
draft = false
tags = ["专著", "出版社"]
title = "《跨越网络的门槛》图书出版计划"
summary = """ """

[header]
image = "headers/amargasaurus.svg"
caption = "Image credit: [**Academic**](https://github.com/gcushen/hugo-academic/)"
+++

<!--more-->

word统计字数，加上空格为16万字。

1．	版面字数 ﹦ 电脑统计字数×1.2＋图片折合版面字数；

16*1.2 = 19.2
